<!DOCTYPE HTML>
<html lang="zh-cmn-hans" xml:lang="zh-cmn-hans">
<head>
<meta http-equiv="Content-Type" content="text/html"; charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Other websites.</title>
</head>
<body>
    <h2>我们支持以下网站:</h2>
    <hr />
	<a href="https://eden.sysu.edu.cn" target="_blank">
    <img src=/image/LOGOwhite256.png alt="Matrix" /></a>
    <a href="http://www.sysu.edu.cn/" target="_blank"><img src=/image/sysu_logo.jpg alt="sysu" /></a>
</body>