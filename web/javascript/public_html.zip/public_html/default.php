<!DOCTYPE HTML>
<html lang="zh-cmn-hans" xml:lang="zh-cmn-hans">

<head>
<meta http-equiv="Content-Type" content="text/html"; charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="stylesheet" href="default.css">
<link rel="icon" href="image/logo.ico" mce_href="image/logo.ico" type="image/x-icon">
<link rel="shortcut icon" href="image/logo.ico" mce_href="image/logo.ico" type="image/x-icon">
<title>EasyGoing-Easy Your Collage Life!</title>
<!--
<script language="javascript">
function clearMessage() {
    document.getElementById("login_name").value = "";
}
function Judge() {
	if (document.getElementById("login_name").value == null) {
		document.getElementById("login_name").value = "手机号/账号/邮箱";
	}
}
</script>
-->
<script src="default.js" type="text/javascript">
</script>
</head>

<body>
<!--These codes are for login and sign up-->
    <div id="log_sign" align="center">
        <form id="login" action="" method="post">
        	<div style="display:inline" id="logname">登录</div>
            <div style="display: inline; margin-left: 10px;">注册</div>
            <p id="account_password">
            	<label for="login_name">账户：</label>
                <input type="text" name="account" id = "login_name" placeholder="手机号/账号/邮箱" style="height:30px" required="required">
                <br>
                <label for="login_password">密码：</label>
                <input type="password" name="password" id="login_password" placeholder="eg: AH666J!X" style="height:30px" required="required">
                <br>
            </p>
        </form>
    </div>
<!--Below is for login and sign up-->
</body>

</html>